function norm(x){ return String(x||'').replace(/[^0-9]/g, ''); }

export default async function handler(req, res){
  try{
    const ref = norm(req.query.ref);
    if(!ref) return res.status(400).json({ error: "ref required" });
    const viewerUrl = `https://bill.pitc.com.pk/fescobill/?ref=${ref}`;
    return res.status(200).json({ disco: "FESCO", viewerUrl });
  }catch(e){ res.status(500).json({ error: "server error" }); }
}
