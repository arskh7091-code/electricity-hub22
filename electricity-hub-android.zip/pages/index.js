
"use client";
import { useState } from "react";

const discos = [
  { key: "iesco", name: "IESCO" },
  { key: "pesco", name: "PESCO" },
  { key: "lesco", name: "LESCO" },
  { key: "mepco", name: "MEPCO" },
  { key: "fesco", name: "FESCO" },
  { key: "gepco", name: "GEPCO" },
  { key: "hesco", name: "HESCO" },
  { key: "sepco", name: "SEPCO" },
  { key: "qesco", name: "QESCO" }
];

export default function Home(){
  const [ref, setRef] = useState("");
  const [company, setCompany] = useState("iesco");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function fetchBill(){
    setLoading(true); setError(null); setData(null);
    try{
      const res = await fetch(`/api/${company}?ref=${encodeURIComponent(ref)}`);
      const json = await res.json();
      if(!res.ok) throw new Error(json.error || "Failed");
      setData(json);
    }catch(e){ setError(e.message); }
    finally{ setLoading(false); }
  }

  return (
    <main className="min-h-screen p-6">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow p-6">
        <h1 className="text-2xl font-bold">Electricity Hub — Pakistan Duplicate Bill</h1>
        <p className="text-sm text-gray-600 mt-1">Pick your DISCO → enter 14‑digit Reference or Customer ID → open/view bill.</p>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <select value={company} onChange={e=>setCompany(e.target.value)} className="border rounded p-2 col-span-2">
            {discos.map(d => <option key={d.key} value={d.key}>{d.name}</option>)}
          </select>
          <input className="border rounded p-2 col-span-2" placeholder="Reference # or Customer ID" value={ref} onChange={e=>setRef(e.target.value)} />
          <button onClick={fetchBill} className="col-span-2 px-4 py-2 rounded bg-blue-600 text-white">Get Bill</button>
        </div>

        {loading && <p className="mt-4 text-yellow-700">Loading…</p>}
        {error && <p className="mt-4 text-red-600">{error}</p>}

        {data && (
          <div className="mt-6 border rounded p-4 bg-gray-50">
            <h2 className="font-semibold">{data.disco} — Official Bill</h2>
            {data.customerName && <p>Customer: <b>{data.customerName}</b></p>}
            {data.amount && <p>Amount: PKR <b>{data.amount}</b></p>}
            {data.dueDate && <p>Due: <b>{data.dueDate}</b></p>}
            <div className="mt-3 flex gap-2 flex-wrap">
              {data.viewerUrl && <a className="px-3 py-2 border rounded" href={data.viewerUrl} target="_blank" rel="noreferrer">Open Official Bill</a>}
              {data.pdfUrl && <a className="px-3 py-2 border rounded" href={data.pdfUrl} target="_blank" rel="noreferrer">Download PDF</a>}
              {data.payLink && <a className="px-3 py-2 bg-green-600 text-white rounded" href={data.payLink} target="_blank" rel="noreferrer">Pay Now</a>}
            </div>
            {data.note && <p className="text-xs text-gray-500 mt-2">{data.note}</p>}
          </div>
        )}
      </div>
    </main>
  );
}
